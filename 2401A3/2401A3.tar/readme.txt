Raden Mathieu Almaden 101104851
Files: fishingSimulator.c , dynamicVersion.c

To compile:
Open command line and head to directory containing the file and type
"gcc -o filename filename.c"

To run:
type in command line
"./filename"

To test for valgrind:
type in command line 
"valgrind --leak-check=full ./filename"
