Purpose: This program was made so it can look through binary files containing large numbers and obtaining their factors. It is also for practice in understanding how to open/close files and process spawning, program morphing, and threads.

Developer: Raden Mathieu Almaden 101104851
Development Date : December 6 2019

Source Files:
createBinary.c
multiFactor.c
numPrimeFactors.c
prime_threads.c

Text and Bin Files:
prime.txt
prime.bin
test.bin

makefiles:
Makefile1
Makefile2

Compiling command:
make -f (makefile)

Execution commands:
For makefile1
	./multispawn (filename)
for makefile2
	./multithread (filename) index1 index2

Limitations/Warnings:
When checking for errors in valgrind or memory leaks in part 2. It significantly takes a while as valgrind looks at every single detail in the code which will then cause it to take a lot longer than just not using valgrind. Also, if the number of factors for any number, ends up being 255, the program will fail as WEXITSTATUS can only handle numbers up to 255. Which in the program is considered -1 as morph will overflow since it's trying to return -1 to WEXITSTATUS.

How to use the software:
Run the makefile commands and then run the execution commands with a bin file that contains ONLY integers. You can place your own bin files within the same directory to use the software. Recall the execution commands and where to put the filenames. If an error occurs, the program will tell you what you will need to do or if something failed.


