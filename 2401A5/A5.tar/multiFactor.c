#include <stdio.h>
#include <unistd.h>
#include "math.h"
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>

#define die(e) do { fprintf(stderr, "%s\n", e); exit(0); } while (0);

//PROTYPES
int morph(char *number);

int main(int argc, char *argv[])

{
  if(argc < 2){
    printf("- Usage: multifactor filename\n");
    return(-2);
  }


  FILE *fd = fopen(argv[1], "r+");
  if(!fd) {
    printf("ERROR: Could not open file \n" );
    return(-2);
  } else {
    printf("file opened... Continuing Program \n\n\n");
  }
  unsigned long int *data; //Array for all the numbers
  long int numRecords = 0; //total numbers in file

  //Figuring out how many numbers are in the file
  fseek(fd, 0, SEEK_END);
  numRecords = ftell(fd);
  fseek(fd,0,SEEK_SET);
  numRecords = numRecords/(sizeof(unsigned long));

  char dataText[numRecords][80]; //Contains the number in text file

  data = (unsigned long int*) malloc(sizeof(unsigned long)*numRecords); //Allocating memory
  fread(data,sizeof(unsigned long), numRecords, fd);
  for(int i = 0 ;i < numRecords; i++){
    printf("Numbers to be analyzed: %lu  \n",data[i]);
    sprintf(dataText[i], "%lu" , data[i]);
  }
  printf("\n\n");

  pid_t pids[numRecords];
  int factors[numRecords];  //Array to keep all the factors of each number
  //Children
  for (int i = 0; i < numRecords; i++) {
    pids[i] = fork();
    if (pids[i] < 0) {
      perror("exit");
      return(-1);
    } else if (pids[i] == 0) {
      morph(dataText[i]);
    }
  }
  //Parent program
  int sumFactors = 0;
  int i = 0;
  //Obtaining all the exit values(factors) from the child processes
  while(1) {
    int status = 0;
    if(waitpid(-1, &status, 0) == -1){
      break;
    } else {

    if(WIFEXITED(status)) {
      factors[i] = WEXITSTATUS(status);
      if(factors[i] == 255){ //Checking if morph failed
        printf("Morph failed as it returned -1 (which ended up converting to 255), ending program \n\nPlease make sure numPrimeFactors was properly compiled and created\n\n");
        return(-1);
      }
      sumFactors += factors[i]; //Sums up the factors
      i++;
    }

    }
  }



  printf("\n\n\nThe total sum of factors for all the numbers is %d \n\n\n", sumFactors);
  fclose(fd);
  free(data);
  return 1;

}


int morph(char *number){
  pid_t pid;
  int cpid;
  int status;
  int link[2];
  char buffer[80];
  char *args[3];
  strcpy(buffer, "./numPrimeFactors");
  args[0] = "numPrimeFactors";
  args[1] = number;
  args[2] = NULL;
  if(execv("./numPrimeFactors",args) == -1){
    exit(-1);  // This shouldnt go here unless the program fails
  }
}
