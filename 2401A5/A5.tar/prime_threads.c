// file is prime_threads.c
/********************************************************************/


/****************************************************************/
// Includes

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
/***************************************************************/
// Structures


// holds the thread information for each thread
typedef struct threadData {
    pthread_t thread_id;			// system thread id
    int tid;                  // inernal id assigned by the program
} ThreadData;


/******************************************************************/
// Define


#define NUM_THREADS 5


/******************************************************************/
// Function Prototypes

int numPrimeFactors(unsigned long number);

/***************************************************************/
// Global Variables
unsigned long totalNumPrimeFactors = 0;		// global value that holds the final result
unsigned long *recordsToProcess = NULL;     // array that will hold al the numbers to be processed
int numRecords = 0;                         // number of records in the array recordsToProcess
pthread_mutex_t myMutex;		// global mutex to block access to critical code

/*************************************************************/
/*
Purpose compute the number of prime factors of a given number
input:
number - the number to be processed

output:
None

Return:
the number of prime factors of number
*/
int numPrimeFactors(unsigned long number)
{
    unsigned long i;
    unsigned long quot;
    int numFactors = 0;

    // base case
    if (number == 1) return(0);
    if (number == 2 || number == 3) return(1);

    // check for the first factor until integer is less then number
    for (i = 2; i <= number; i++) {
        if (i % 1000 == 0) {
            if (number / i == 1) return(1);   // cannot have any more factrs other than self
        }
        if (number % i == 0) {
            quot = number / i;
            if (quot == 1) return(1);   // cannot have any more factrs other than self
            numFactors = 1 + numPrimeFactors(quot);
            return(numFactors);
        }
    }
    return(0);
}
/*************************************************************************/
//Purpose: the main function of the threads

void *threadMain(int index[2])

{

  for(int i = index[0]; i < index[1];i++){
    pthread_mutex_lock(&myMutex);
    totalNumPrimeFactors += numPrimeFactors(*(recordsToProcess+i)); //Updating the sum of factors
    pthread_mutex_unlock(&myMutex);
  }
    // add code
}

/*************************************************************************/
int main(int argc, char ** argv)
{
  if(argc <= 2){
    printf("- Usage: multithread <filename> index1 index2 \n");
    return(-2);
  }
  //initializing mutex
  pthread_mutex_init(&myMutex,NULL);

  //Reading records from file
  FILE *fd;
  fd = fopen(argv[1], "r+");
  if(!fd) {
    printf("ERROR: Could not open file \n" );
    return(-2);
  } else {
    printf("file opened... Continuing Program \n\n\n");
  }
  int Totalnumbers = 0;
  fseek(fd, 0, SEEK_END);
  Totalnumbers = ftell(fd);
  fseek(fd,0,SEEK_SET);
  Totalnumbers = Totalnumbers/(sizeof(unsigned long));
  int totalNumsNeeded = 0;
  // read the records from the file


  // initialize the threads


  // wait for the threads to terminate

  // destroy the mutex


  // print the numer of prime factors
  int checker = 0 ;

  //Checking whether or not to see if all numbers will be needed to checked
  if((strtol(*(argv+2),NULL,0)) == -1){
    checker = 1;
    fseek(fd, 0, SEEK_END);
    numRecords = ftell(fd);
    fseek(fd,0,SEEK_SET);
    numRecords = numRecords/(sizeof(unsigned long));

    recordsToProcess = (unsigned long *) malloc(sizeof(unsigned long)*Totalnumbers);
    fread(recordsToProcess,sizeof(unsigned long), Totalnumbers, fd);

  }else{
    checker = 2;
    int argcount = 2;
    //Figuring out how many recorsd are needed
    while(argcount < argc){
      numRecords++;
      totalNumsNeeded++;
      argcount++;
    }

    //Resetting argcount to reloop through again
    argcount = 2;
    int count = 0;

    recordsToProcess = (unsigned long *) malloc(sizeof(unsigned long)*totalNumsNeeded);

    while(argcount < (argc)){
      long int number = strtol(*(argv+argcount),NULL,0);
      if(number > 0 && number <= Totalnumbers){
        unsigned long buffer[1];
        unsigned long primeNum;
        int lineCount = 0;
        while(lineCount < number - 1){ //Traversing to the n'th line so the next fread will obtain the needed prime
          fread(buffer, sizeof(unsigned long), 1 ,fd);
          lineCount++;
        }
        fread(&primeNum, sizeof(unsigned long), 1 , fd); //It doesn't specify to only use 1 fread for each prime
        *(recordsToProcess+count) = primeNum;
        count++;
        fseek(fd, 0, SEEK_SET);  //Goes back to the beginning of the file for the next n'th prime number
        lineCount = 0;
      } else {
        printf("The index('s) is out of boundaries of the file\n\nThe boundaries for this file are 1 -> %d\n\nEnding program\n\n",Totalnumbers);
        return(-1);
      }
      argcount++; //Going through each index
    }

  }

  pthread_t tid[NUM_THREADS];
  int  i, rc;
  ThreadData tdata[NUM_THREADS];		// holds the tasks for each thread
  int numberstoCheck = 0;
  if(checker == 1){
    numberstoCheck = Totalnumbers;
  } else {
    numberstoCheck = totalNumsNeeded;
  }
  //Needed varaibles to balance how many primes each thread will calculate
  int numPerThread = 0;
  numPerThread = (int) numberstoCheck / 5; //Here numRecords is being used to identify how to distribute how numbers between threads
  int remainders = numberstoCheck%5;
  if(remainders != 0){  //If the number of records doesn't distribute evenly, numPerThread adds one extra for the threads to account for remainders
    numPerThread++;
  }
  totalNumPrimeFactors = 0;
  int indexdiff = 0; //This will account for remainders and the range difference if there is remainders
  int range[5][2]; //This is the index range for each thread to calculate factors for primes

  for (i = 0; i<NUM_THREADS; i++) {
      if(i == numberstoCheck){
        break;
      }
      tdata[i].tid = i;
      if(remainders != 0){ //If the remainders is not even yet, it will slowly iterate down until the remainders are accounted for in the threads
        range[i][0] = i*numPerThread;
        range[i][1] = (i+1)*numPerThread;
        remainders--;
        indexdiff++; //indexdiff has to iterate up to account for the index change when some threads are doing an extra
        if(remainders == 0){ //Once remainders reaches 0, the rest of the threads will no longer need to do an extra number
          numPerThread--;
        }
      } else { //Normal ranges when the remainder is 0
        range[i][0] = (i*numPerThread)+indexdiff;
        range[i][1] = ((i+1)*numPerThread)+indexdiff;
      }
      printf("create thread %d \n",i);
      printf("Indexes are %d AND %d \n\n",range[i][0],range[i][1]);
      rc = pthread_create(&tid[i], NULL, threadMain,range[i]);
      if (rc) {
          fprintf(stderr, "Error, exiting\n");
          exit(1);
      }
      tdata[i].thread_id = tid[i];
      usleep(100);
  }


  for (i = 0; i < NUM_THREADS; i++){
    pthread_join(tid[i], NULL); //Joining all the threads
    if(i == numberstoCheck-1 && numberstoCheck < NUM_THREADS){
      break;
    }
  }

  printf("\n\n The total sum of the prime factors is = %lu \n",totalNumPrimeFactors);

  pthread_mutex_destroy(&myMutex);
  free(recordsToProcess);
  fclose(fd);


}
